# MADPractical4_21012022022

AIM: What is Intent? Write down types of Intent and types of Intent Action. Create an application which demonstrates implicit Intent for following features and also create different activities and demonstrate explicit Intent. Use parent theme Theme.Material3.Dark.NoActionBar for Dark theme and Theme.Material3.Light.NoActionBar for Light Theme

1. Make call to specific number
2. Open specific URL
3. Pick up Contact from Existing contact list
4. Open Call Log
5. Open Gallery
6. Set Alarm
7. Open Camera

Study: Intent, types of Intent, types of Intent Action, Intent.setData() method, Intent.setType() method, TextInputEditText, TextInputLayout, Button, ConstraintLayout, CoordinatorLayout, startActivity() method, ActivityResultContracts.StartActivityForResult() method, registerForActivityResult() method, Permission in manifest, ContextCompat.checkSelfPermission(), ActivityCompat.requestPermissions() method, Uri.parse() method, 

ContactsContract.Contacts.CONTENT_TYPE

CallLog.Calls.CONTENT_TYPE

"image/*"

"tel:"

<uses-permission android:name="android.permission.READ_CONTACTS" />


![image](https://user-images.githubusercontent.com/110646988/189613495-3067eced-56df-44f2-ae58-bc3263355605.png)
